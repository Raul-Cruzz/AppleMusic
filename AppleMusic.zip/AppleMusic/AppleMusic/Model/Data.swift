import Foundation

let urlDownloads: [String] = ["https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview125/v4/48/73/5e/48735efc-cb85-c66e-a670-19c718c57d07/mzaf_6763775615899653702.plus.aac.p.m4a", "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview115/v4/fc/5d/b1/fc,5db184-9dcd-d575-f3f9-2fb63190d863/mzaf_15771304045282268392.plus.aac.p.m4a",
"https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview115/v4/d5/00/0c/d5000c4c-0fc7-c4d1-120a-75e9c7597736/mzaf_15078972657729115288.plus.aac.p.m4a",
                              "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview115/v4/d5/00/0c/d5000c4c-0fc7-c4d1-120a-75e9c7597736/mzaf_15078972657729115288.plus.aac.p.m4a",
                              "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview116/v4/71/29/9a/71299a52-936d-5ffe-4c87-616da6c0000e/mzaf_12283394856802960166.plus.aac.p.m4a",
                              "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview115/v4/73/58/72/7358729f-9ff8-5a38-8a91-e4e9c2ad01b8/mzaf_11787442250493085221.plus.aac.p.m4a"]
